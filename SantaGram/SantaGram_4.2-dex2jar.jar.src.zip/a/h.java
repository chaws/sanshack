package a;

public abstract interface h<TTaskResult, TContinuationResult>
{
  public abstract TContinuationResult then(j<TTaskResult> paramj);
}


/* Location:              /home/cdo/tmp/sanshack/SantaGram_4.2-dex2jar.jar!/a/h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */