package a;

public class i
  extends RuntimeException
{
  public i(Exception paramException)
  {
    super("An exception was thrown by an Executor", paramException);
  }
}


/* Location:              /home/cdo/tmp/sanshack/SantaGram_4.2-dex2jar.jar!/a/i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */