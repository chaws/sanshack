package a;

public class g<T>
{
  private T a;
  
  public g() {}
  
  public g(T paramT)
  {
    this.a = paramT;
  }
  
  public T a()
  {
    return (T)this.a;
  }
  
  public void a(T paramT)
  {
    this.a = paramT;
  }
}


/* Location:              /home/cdo/tmp/sanshack/SantaGram_4.2-dex2jar.jar!/a/g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */