package a;

public class m
  extends RuntimeException
{
  public m(Throwable paramThrowable)
  {
    super(paramThrowable);
  }
}


/* Location:              /home/cdo/tmp/sanshack/SantaGram_4.2-dex2jar.jar!/a/m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */