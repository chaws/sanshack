package com.parse.a;

public abstract interface d
{
  public abstract c intercept(a parama);
  
  public static abstract interface a
  {
    public abstract b getRequest();
    
    public abstract c proceed(b paramb);
  }
}


/* Location:              /home/cdo/tmp/sanshack/SantaGram_4.2-dex2jar.jar!/com/parse/a/d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */