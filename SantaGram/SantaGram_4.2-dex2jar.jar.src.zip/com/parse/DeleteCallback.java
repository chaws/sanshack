package com.parse;

public abstract interface DeleteCallback
  extends ParseCallback1<ParseException>
{
  public abstract void done(ParseException paramParseException);
}


/* Location:              /home/cdo/tmp/sanshack/SantaGram_4.2-dex2jar.jar!/com/parse/DeleteCallback.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */