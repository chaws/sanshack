package com.parse;

public abstract interface CountCallback
{
  public abstract void done(int paramInt, ParseException paramParseException);
}


/* Location:              /home/cdo/tmp/sanshack/SantaGram_4.2-dex2jar.jar!/com/parse/CountCallback.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */