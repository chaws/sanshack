package com.northpolewonderland.santagram;

import android.app.Activity;

public class a
{
  Activity a;
  
  public a(Activity paramActivity)
  {
    this.a = paramActivity;
  }
}


/* Location:              /home/cdo/tmp/sanshack/SantaGram_4.2-dex2jar.jar!/com/northpolewonderland/santagram/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */