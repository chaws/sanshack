package android.support.design.widget;

import android.support.v4.j.aa;
import android.support.v4.j.af;
import android.view.View;

class d
  implements c
{
  public void a(View paramView, aa paramaa)
  {
    if (af.t(paramView))
    {
      af.a(paramView, paramaa);
      paramView.setSystemUiVisibility(1280);
    }
  }
}


/* Location:              /home/cdo/tmp/sanshack/SantaGram_4.2-dex2jar.jar!/android/support/design/widget/d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */