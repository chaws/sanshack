package android.support.v4.j;

import android.view.View;

public abstract interface aa
{
  public abstract bc a(View paramView, bc parambc);
}


/* Location:              /home/cdo/tmp/sanshack/SantaGram_4.2-dex2jar.jar!/android/support/v4/j/aa.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */