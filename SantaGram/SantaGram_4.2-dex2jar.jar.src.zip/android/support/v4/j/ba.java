package android.support.v4.j;

import android.view.View;

public class ba
  implements az
{
  public void a(View paramView) {}
  
  public void b(View paramView) {}
  
  public void c(View paramView) {}
}


/* Location:              /home/cdo/tmp/sanshack/SantaGram_4.2-dex2jar.jar!/android/support/v4/j/ba.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */