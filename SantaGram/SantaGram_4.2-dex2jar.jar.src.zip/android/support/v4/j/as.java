package android.support.v4.j;

import android.view.ViewConfiguration;

class as
{
  static boolean a(ViewConfiguration paramViewConfiguration)
  {
    return paramViewConfiguration.hasPermanentMenuKey();
  }
}


/* Location:              /home/cdo/tmp/sanshack/SantaGram_4.2-dex2jar.jar!/android/support/v4/j/as.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */