package android.support.v4.j;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff.Mode;

public abstract interface ac
{
  public abstract ColorStateList getSupportBackgroundTintList();
  
  public abstract PorterDuff.Mode getSupportBackgroundTintMode();
  
  public abstract void setSupportBackgroundTintList(ColorStateList paramColorStateList);
  
  public abstract void setSupportBackgroundTintMode(PorterDuff.Mode paramMode);
}


/* Location:              /home/cdo/tmp/sanshack/SantaGram_4.2-dex2jar.jar!/android/support/v4/j/ac.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */