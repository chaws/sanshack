package android.support.v4.j;

import android.view.View;
import android.view.ViewGroup;

public class z
{
  private final ViewGroup a;
  private int b;
  
  public z(ViewGroup paramViewGroup)
  {
    this.a = paramViewGroup;
  }
  
  public int a()
  {
    return this.b;
  }
  
  public void a(View paramView)
  {
    this.b = 0;
  }
  
  public void a(View paramView1, View paramView2, int paramInt)
  {
    this.b = paramInt;
  }
}


/* Location:              /home/cdo/tmp/sanshack/SantaGram_4.2-dex2jar.jar!/android/support/v4/j/z.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */