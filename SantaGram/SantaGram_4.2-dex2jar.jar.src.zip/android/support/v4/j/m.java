package android.support.v4.j;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;

public abstract interface m
{
  public abstract View a(View paramView, String paramString, Context paramContext, AttributeSet paramAttributeSet);
}


/* Location:              /home/cdo/tmp/sanshack/SantaGram_4.2-dex2jar.jar!/android/support/v4/j/m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */