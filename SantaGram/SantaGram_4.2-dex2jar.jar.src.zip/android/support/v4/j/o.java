package android.support.v4.j;

import android.view.ViewGroup.MarginLayoutParams;

class o
{
  public static int a(ViewGroup.MarginLayoutParams paramMarginLayoutParams)
  {
    return paramMarginLayoutParams.getMarginStart();
  }
  
  public static int b(ViewGroup.MarginLayoutParams paramMarginLayoutParams)
  {
    return paramMarginLayoutParams.getMarginEnd();
  }
}


/* Location:              /home/cdo/tmp/sanshack/SantaGram_4.2-dex2jar.jar!/android/support/v4/j/o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */