package android.support.v4.j;

import android.view.LayoutInflater;

class l
{
  static void a(LayoutInflater paramLayoutInflater, m paramm)
  {
    if (paramm != null) {}
    for (paramm = new k.a(paramm);; paramm = null)
    {
      paramLayoutInflater.setFactory2(paramm);
      return;
    }
  }
}


/* Location:              /home/cdo/tmp/sanshack/SantaGram_4.2-dex2jar.jar!/android/support/v4/j/l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */