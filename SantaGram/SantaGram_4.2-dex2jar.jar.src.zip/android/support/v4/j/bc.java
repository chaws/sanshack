package android.support.v4.j;

public class bc
{
  public int a()
  {
    return 0;
  }
  
  public bc a(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    return this;
  }
  
  public int b()
  {
    return 0;
  }
  
  public int c()
  {
    return 0;
  }
  
  public int d()
  {
    return 0;
  }
  
  public boolean e()
  {
    return false;
  }
}


/* Location:              /home/cdo/tmp/sanshack/SantaGram_4.2-dex2jar.jar!/android/support/v4/j/bc.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */