package android.support.v4.j;

import android.view.View;

class an
{
  public static void a(View paramView, int paramInt)
  {
    paramView.setAccessibilityLiveRegion(paramInt);
  }
  
  public static boolean a(View paramView)
  {
    return paramView.isLaidOut();
  }
  
  public static boolean b(View paramView)
  {
    return paramView.isAttachedToWindow();
  }
}


/* Location:              /home/cdo/tmp/sanshack/SantaGram_4.2-dex2jar.jar!/android/support/v4/j/an.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */