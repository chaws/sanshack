package android.support.v4.j.a;

import android.view.accessibility.AccessibilityRecord;

class m
{
  public static void a(Object paramObject, int paramInt)
  {
    ((AccessibilityRecord)paramObject).setMaxScrollX(paramInt);
  }
  
  public static void b(Object paramObject, int paramInt)
  {
    ((AccessibilityRecord)paramObject).setMaxScrollY(paramInt);
  }
}


/* Location:              /home/cdo/tmp/sanshack/SantaGram_4.2-dex2jar.jar!/android/support/v4/j/a/m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */