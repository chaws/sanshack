package android.support.v4.j;

public abstract interface w
{
  public abstract void stopNestedScroll();
}


/* Location:              /home/cdo/tmp/sanshack/SantaGram_4.2-dex2jar.jar!/android/support/v4/j/w.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */