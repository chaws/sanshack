package android.support.v4.e.a;

import android.view.SubMenu;

public abstract interface c
  extends a, SubMenu
{}


/* Location:              /home/cdo/tmp/sanshack/SantaGram_4.2-dex2jar.jar!/android/support/v4/e/a/c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */