package android.support.v4.f.a;

public final class a
{
  private final a a;
  
  public Object a()
  {
    return this.a.a();
  }
  
  static abstract interface a
  {
    public abstract Object a();
  }
}


/* Location:              /home/cdo/tmp/sanshack/SantaGram_4.2-dex2jar.jar!/android/support/v4/f/a/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */