package android.support.v4.g;

import android.os.Parcel;

public abstract interface d<T>
{
  public abstract T b(Parcel paramParcel, ClassLoader paramClassLoader);
  
  public abstract T[] b(int paramInt);
}


/* Location:              /home/cdo/tmp/sanshack/SantaGram_4.2-dex2jar.jar!/android/support/v4/g/d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */