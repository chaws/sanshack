package android.support.v4.g;

import android.os.Build.VERSION;

public final class g
{
  public static void a()
  {
    if (Build.VERSION.SDK_INT >= 18) {
      h.a();
    }
  }
  
  public static void a(String paramString)
  {
    if (Build.VERSION.SDK_INT >= 18) {
      h.a(paramString);
    }
  }
}


/* Location:              /home/cdo/tmp/sanshack/SantaGram_4.2-dex2jar.jar!/android/support/v4/g/g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */