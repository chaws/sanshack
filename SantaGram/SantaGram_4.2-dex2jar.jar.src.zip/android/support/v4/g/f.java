package android.support.v4.g;

import android.os.Parcelable.Creator;

class f
{
  static <T> Parcelable.Creator<T> a(d<T> paramd)
  {
    return new e(paramd);
  }
}


/* Location:              /home/cdo/tmp/sanshack/SantaGram_4.2-dex2jar.jar!/android/support/v4/g/f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */