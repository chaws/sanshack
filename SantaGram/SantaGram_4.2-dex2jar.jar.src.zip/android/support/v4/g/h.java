package android.support.v4.g;

import android.os.Trace;

class h
{
  public static void a() {}
  
  public static void a(String paramString)
  {
    Trace.beginSection(paramString);
  }
}


/* Location:              /home/cdo/tmp/sanshack/SantaGram_4.2-dex2jar.jar!/android/support/v4/g/h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */