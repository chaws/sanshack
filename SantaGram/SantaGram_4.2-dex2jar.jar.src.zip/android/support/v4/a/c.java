package android.support.v4.a;

import android.view.View;

class c
  implements b
{
  public void a(View paramView) {}
}


/* Location:              /home/cdo/tmp/sanshack/SantaGram_4.2-dex2jar.jar!/android/support/v4/a/c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */