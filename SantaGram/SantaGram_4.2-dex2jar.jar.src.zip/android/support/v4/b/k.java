package android.support.v4.b;

abstract class k
  extends j
{
  void onBackPressedNotHandled()
  {
    super.onBackPressed();
  }
}


/* Location:              /home/cdo/tmp/sanshack/SantaGram_4.2-dex2jar.jar!/android/support/v4/b/k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */