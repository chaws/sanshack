package android.support.v4.b;

import android.app.Activity;

class d
{
  static void a(Activity paramActivity)
  {
    paramActivity.invalidateOptionsMenu();
  }
}


/* Location:              /home/cdo/tmp/sanshack/SantaGram_4.2-dex2jar.jar!/android/support/v4/b/d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */