package android.support.v4.b;

import android.view.View;

public abstract class o
{
  public abstract View a(int paramInt);
  
  public abstract boolean a();
}


/* Location:              /home/cdo/tmp/sanshack/SantaGram_4.2-dex2jar.jar!/android/support/v4/b/o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */