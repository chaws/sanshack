package android.support.v4.b;

import android.content.Context;
import android.content.res.Configuration;
import android.os.Parcelable;
import android.support.v4.i.i;
import android.util.AttributeSet;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.List;

public class p
{
  private final q<?> a;
  
  private p(q<?> paramq)
  {
    this.a = paramq;
  }
  
  public static final p a(q<?> paramq)
  {
    return new p(paramq);
  }
  
  m a(String paramString)
  {
    return this.a.d.b(paramString);
  }
  
  public r a()
  {
    return this.a.i();
  }
  
  public View a(View paramView, String paramString, Context paramContext, AttributeSet paramAttributeSet)
  {
    return this.a.d.a(paramView, paramString, paramContext, paramAttributeSet);
  }
  
  public void a(Configuration paramConfiguration)
  {
    this.a.d.a(paramConfiguration);
  }
  
  public void a(Parcelable paramParcelable, List<m> paramList)
  {
    this.a.d.a(paramParcelable, paramList);
  }
  
  public void a(m paramm)
  {
    this.a.d.a(this.a, this.a, paramm);
  }
  
  public void a(i<String, x> parami)
  {
    this.a.a(parami);
  }
  
  public void a(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString)
  {
    this.a.b(paramString, paramFileDescriptor, paramPrintWriter, paramArrayOfString);
  }
  
  public void a(boolean paramBoolean)
  {
    this.a.a(paramBoolean);
  }
  
  public boolean a(Menu paramMenu)
  {
    return this.a.d.a(paramMenu);
  }
  
  public boolean a(Menu paramMenu, MenuInflater paramMenuInflater)
  {
    return this.a.d.a(paramMenu, paramMenuInflater);
  }
  
  public boolean a(MenuItem paramMenuItem)
  {
    return this.a.d.a(paramMenuItem);
  }
  
  public x b()
  {
    return this.a.j();
  }
  
  public void b(Menu paramMenu)
  {
    this.a.d.b(paramMenu);
  }
  
  public boolean b(MenuItem paramMenuItem)
  {
    return this.a.d.b(paramMenuItem);
  }
  
  public void c()
  {
    this.a.d.h();
  }
  
  public Parcelable d()
  {
    return this.a.d.g();
  }
  
  public List<m> e()
  {
    return this.a.d.f();
  }
  
  public void f()
  {
    this.a.d.i();
  }
  
  public void g()
  {
    this.a.d.j();
  }
  
  public void h()
  {
    this.a.d.k();
  }
  
  public void i()
  {
    this.a.d.l();
  }
  
  public void j()
  {
    this.a.d.m();
  }
  
  public void k()
  {
    this.a.d.n();
  }
  
  public void l()
  {
    this.a.d.o();
  }
  
  public void m()
  {
    this.a.d.q();
  }
  
  public void n()
  {
    this.a.d.r();
  }
  
  public boolean o()
  {
    return this.a.d.d();
  }
  
  public void p()
  {
    this.a.l();
  }
  
  public void q()
  {
    this.a.m();
  }
  
  public void r()
  {
    this.a.n();
  }
  
  public i<String, x> s()
  {
    return this.a.o();
  }
}


/* Location:              /home/cdo/tmp/sanshack/SantaGram_4.2-dex2jar.jar!/android/support/v4/b/p.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */