package android.support.v4.b;

import android.os.Bundle;
import android.support.v4.c.g;

public abstract class x
{
  public boolean a()
  {
    return false;
  }
  
  public static abstract interface a<D>
  {
    public abstract g<D> a(int paramInt, Bundle paramBundle);
    
    public abstract void a(g<D> paramg);
    
    public abstract void a(g<D> paramg, D paramD);
  }
}


/* Location:              /home/cdo/tmp/sanshack/SantaGram_4.2-dex2jar.jar!/android/support/v4/b/x.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */