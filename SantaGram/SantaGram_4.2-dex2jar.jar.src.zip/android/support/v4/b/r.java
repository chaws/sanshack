package android.support.v4.b;

import java.io.FileDescriptor;
import java.io.PrintWriter;

public abstract class r
{
  public abstract void a(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString);
  
  public abstract boolean a();
  
  public static abstract interface a
  {
    public abstract void a();
  }
}


/* Location:              /home/cdo/tmp/sanshack/SantaGram_4.2-dex2jar.jar!/android/support/v4/b/r.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */