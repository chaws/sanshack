package android.support.v4.b;

import android.util.AndroidRuntimeException;

final class ad
  extends AndroidRuntimeException
{
  public ad(String paramString)
  {
    super(paramString);
  }
}


/* Location:              /home/cdo/tmp/sanshack/SantaGram_4.2-dex2jar.jar!/android/support/v4/b/ad.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */