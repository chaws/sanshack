package android.support.v4.c;

import android.content.Context;
import android.graphics.drawable.Drawable;

class b
{
  public static Drawable a(Context paramContext, int paramInt)
  {
    return paramContext.getDrawable(paramInt);
  }
}


/* Location:              /home/cdo/tmp/sanshack/SantaGram_4.2-dex2jar.jar!/android/support/v4/c/b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */