package android.support.v4.c;

import android.content.ComponentName;
import android.content.Intent;

class f
{
  public static Intent a(ComponentName paramComponentName)
  {
    return Intent.makeMainActivity(paramComponentName);
  }
}


/* Location:              /home/cdo/tmp/sanshack/SantaGram_4.2-dex2jar.jar!/android/support/v4/c/f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */