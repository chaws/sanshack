package android.support.v4.c;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

class d
{
  public static void a(Context paramContext, Intent[] paramArrayOfIntent, Bundle paramBundle)
  {
    paramContext.startActivities(paramArrayOfIntent, paramBundle);
  }
}


/* Location:              /home/cdo/tmp/sanshack/SantaGram_4.2-dex2jar.jar!/android/support/v4/c/d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */