package android.support.v4.c;

import android.content.Context;
import android.content.Intent;

class c
{
  static void a(Context paramContext, Intent[] paramArrayOfIntent)
  {
    paramContext.startActivities(paramArrayOfIntent);
  }
}


/* Location:              /home/cdo/tmp/sanshack/SantaGram_4.2-dex2jar.jar!/android/support/v4/c/c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */