package android.support.v7.view.menu;

import android.content.Context;

public abstract interface l
{
  public abstract void a(Context paramContext, f paramf);
  
  public abstract void a(f paramf, boolean paramBoolean);
  
  public abstract boolean a(f paramf, h paramh);
  
  public abstract boolean a(p paramp);
  
  public abstract void b(boolean paramBoolean);
  
  public abstract boolean b();
  
  public abstract boolean b(f paramf, h paramh);
  
  public static abstract interface a
  {
    public abstract void a(f paramf, boolean paramBoolean);
    
    public abstract boolean a(f paramf);
  }
}


/* Location:              /home/cdo/tmp/sanshack/SantaGram_4.2-dex2jar.jar!/android/support/v7/view/menu/l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */