package android.support.v7.view.menu;

public abstract interface m
{
  public abstract void a(f paramf);
  
  public static abstract interface a
  {
    public abstract void a(h paramh, int paramInt);
    
    public abstract boolean a();
    
    public abstract h getItemData();
  }
}


/* Location:              /home/cdo/tmp/sanshack/SantaGram_4.2-dex2jar.jar!/android/support/v7/view/menu/m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */