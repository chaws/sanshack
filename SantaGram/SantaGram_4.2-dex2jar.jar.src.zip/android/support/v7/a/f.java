package android.support.v7.a;

import android.support.v7.view.b;
import android.support.v7.view.b.a;

public abstract interface f
{
  public abstract void onSupportActionModeFinished(b paramb);
  
  public abstract void onSupportActionModeStarted(b paramb);
  
  public abstract b onWindowStartingSupportActionMode(b.a parama);
}


/* Location:              /home/cdo/tmp/sanshack/SantaGram_4.2-dex2jar.jar!/android/support/v7/a/f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */