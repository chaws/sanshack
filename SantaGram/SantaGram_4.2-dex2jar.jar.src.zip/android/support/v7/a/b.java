package android.support.v7.a;

public class b
{
  public static abstract interface a {}
}


/* Location:              /home/cdo/tmp/sanshack/SantaGram_4.2-dex2jar.jar!/android/support/v7/a/b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */