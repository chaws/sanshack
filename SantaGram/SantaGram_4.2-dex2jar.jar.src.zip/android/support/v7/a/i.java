package android.support.v7.a;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.Window;

class i
  extends l
{
  i(Context paramContext, Window paramWindow, f paramf)
  {
    super(paramContext, paramWindow, paramf);
  }
  
  View b(View paramView, String paramString, Context paramContext, AttributeSet paramAttributeSet)
  {
    return null;
  }
}


/* Location:              /home/cdo/tmp/sanshack/SantaGram_4.2-dex2jar.jar!/android/support/v7/a/i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */