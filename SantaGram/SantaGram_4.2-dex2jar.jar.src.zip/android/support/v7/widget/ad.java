package android.support.v7.widget;

import android.support.v7.view.menu.l.a;
import android.view.Menu;
import android.view.Window.Callback;

public abstract interface ad
{
  public abstract void a(int paramInt);
  
  public abstract void a(Menu paramMenu, l.a parama);
  
  public abstract boolean d();
  
  public abstract boolean e();
  
  public abstract boolean f();
  
  public abstract boolean g();
  
  public abstract boolean h();
  
  public abstract void i();
  
  public abstract void j();
  
  public abstract void setWindowCallback(Window.Callback paramCallback);
  
  public abstract void setWindowTitle(CharSequence paramCharSequence);
}


/* Location:              /home/cdo/tmp/sanshack/SantaGram_4.2-dex2jar.jar!/android/support/v7/widget/ad.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */