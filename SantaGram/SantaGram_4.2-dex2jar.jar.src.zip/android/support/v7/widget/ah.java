package android.support.v7.widget;

import android.graphics.Rect;

public abstract interface ah
{
  public abstract void setOnFitSystemWindowsListener(a parama);
  
  public static abstract interface a
  {
    public abstract void a(Rect paramRect);
  }
}


/* Location:              /home/cdo/tmp/sanshack/SantaGram_4.2-dex2jar.jar!/android/support/v7/widget/ah.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */