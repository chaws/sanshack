package android.support.v7.widget;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff.Mode;

class az
{
  public ColorStateList a;
  public PorterDuff.Mode b;
  public boolean c;
  public boolean d;
  
  void a()
  {
    this.a = null;
    this.d = false;
    this.b = null;
    this.c = false;
  }
}


/* Location:              /home/cdo/tmp/sanshack/SantaGram_4.2-dex2jar.jar!/android/support/v7/widget/az.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */