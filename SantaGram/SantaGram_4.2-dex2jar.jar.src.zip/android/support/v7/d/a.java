package android.support.v7.d;

public final class a
{
  public static final class a
  {
    public static final int[] RecyclerView = { 16842948, 2130772182, 2130772183, 2130772184, 2130772185 };
    public static final int RecyclerView_android_orientation = 0;
    public static final int RecyclerView_layoutManager = 1;
    public static final int RecyclerView_reverseLayout = 3;
    public static final int RecyclerView_spanCount = 2;
    public static final int RecyclerView_stackFromEnd = 4;
  }
}


/* Location:              /home/cdo/tmp/sanshack/SantaGram_4.2-dex2jar.jar!/android/support/v7/d/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */